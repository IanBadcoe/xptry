<?php

return array(
	'author'         => 'EllisLab',
	'author_url'     => 'https://ellislab.com/',
	'name'           => 'ExpressionEngine FilePicker',
	'description'    => "The world's most flexible file picker.",
	'version'        => '1.0.0',
	'namespace'      => 'EllisLab\Addons\FilePicker',
	'settings_exist' => TRUE,
	'built_in'       => TRUE
);