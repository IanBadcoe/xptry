<?php

return array(
	'author'      => 'EllisLab',
	'author_url'  => 'https://ellislab.com/',
	'name'        => 'XML Encode',
	'description' => 'XML Encoding plugin',
	'version'     => '2.0.0',
	'namespace'   => 'EllisLab\Addons\XmlEncode',
	'settings_exist' => FALSE,
	'plugin.typography' => TRUE
);

// EOF
