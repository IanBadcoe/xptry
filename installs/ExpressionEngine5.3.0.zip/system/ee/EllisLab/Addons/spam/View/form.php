<div class='box'>
	<?= $this->make('ee:_shared/form')->render($data); ?>
</div>
