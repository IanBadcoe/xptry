<?php

return array(
	'author'      => 'EllisLab',
	'author_url'  => 'https://ellislab.com/',
	'name'        => 'Pages',
	'description' => '',
	'version'     => '2.2.0',
	'namespace'   => 'EllisLab\Addons\Foo',
	'settings_exist' => TRUE,
);
