<?php

return array(
	'author'         => 'EllisLab',
	'author_url'     => 'https://ellislab.com/',
	'name'           => 'Toggle',
	'description'    => 'On/Off Toggle Switch',
	'version'        => '1.0.0',
	'namespace'      => 'EllisLab\Addons\ToggleField',
	'settings_exist' => FALSE,
	'built_in'       => TRUE,
);