<?php

return array(
	'author'         => 'EllisLab',
	'author_url'     => 'https://ellislab.com/',
	'name'           => 'Date',
	'description'    => '',
	'version'        => '1.0.0',
	'namespace'      => 'EllisLab\Addons\Date',
	'settings_exist' => FALSE,
	'built_in'       => TRUE,
	'fieldtypes'     => array(
		'date' => array(
			'compatibility' => 'date'
		)
	)
);