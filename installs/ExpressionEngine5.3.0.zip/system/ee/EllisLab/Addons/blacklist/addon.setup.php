<?php

return array(
	'author'      => 'EllisLab',
	'author_url'  => 'https://ellislab.com/',
	'name'        => 'Blacklist',
	'description' => '',
	'version'     => '3.0.1',
	'namespace'   => 'EllisLab\Addons\Blacklist',
	'settings_exist' => TRUE,
);