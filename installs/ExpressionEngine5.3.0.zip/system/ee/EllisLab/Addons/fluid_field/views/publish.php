<div class="fluid-wrap" data-field-count="0">
	<div class="js-sorting-container">
		<?=$fields?>
	</div>
	<div class="fluid-actions">
		<?=$filters?>
	</div>
	<div class="fluid-field-templates hidden">
		<?=$field_templates?>
	</div>
</div>
