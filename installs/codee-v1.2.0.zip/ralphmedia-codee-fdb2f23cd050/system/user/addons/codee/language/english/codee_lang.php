<?php
$lang = array(

// Required for MODULES page

'my_module_module_name'     => 'Codee Template Manager',
'my_module_module_description'  => 'The IDE for EE',

//----------------------------------------

// Additional Key => Value pairs go here

// END
);

