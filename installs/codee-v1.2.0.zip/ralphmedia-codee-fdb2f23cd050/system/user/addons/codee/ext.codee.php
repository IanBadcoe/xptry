<?php
if (! defined('BASEPATH')) {
    exit('No direct script access allowed');
}


require_once PATH_THIRD . 'codee/addon.setup.php';

class Codee_ext
{

    public $name           = CODEE_NAME;
    public $version        = CODEE_VERSION;
    public $description    = CODEE_DESCRIPTION;
    public $settings_exist = CODEE_SETTINGS_EXIST;
    public $docs_url       = CODEE_DOCS;
    public $settings       = array();
    // public $required_by    = array('Module');

    /**
     * Extension Constructor
     */
    public function __construct($settings = '')
    {
        $this->settings = $settings;
    }

    // --------------------------------------------------------------------

    /**
     * Activate Extension
     */
    public function activate_extension()
    {
        $hooks = array('cp_custom_menu');

        foreach ($hooks as $hook) {
            ee()->db->insert(
                'extensions',
                array(
                    'class'    => __CLASS__,
                    'hook'     => $hook,
                    'method'   => $hook,
                    'settings' => '',
                    'priority' => 10,
                    'version'  => $this->version,
                    'enabled'  => 'y'
                )
            );
        }
        
    }

    

    public function settings()
    {
        return array();
    }

    /**
     * Update Extension
     */
    public function update_extension($current = '')
    {
        if ($current === '' or $current === $this->version) {
            return false;
        }

        ee()->db->update('extensions', array('version' => $this->version), array('class' => __CLASS__));
    }

    /**
     * Disable Extension
     */
    public function disable_extension()
    {
        ee()->db->delete('extensions', array('class' => __CLASS__));
    }

    public function cp_custom_menu($menu)
    {
//    	die('test');
        // call addItem to create a link in this menu
		$menu->addItem('Codee Template Manager', ee('CP/URL')->make('/cp/addons/settings/codee'));
		// call addSubmenu to create a dropdown menu
		// this returns a submenu object
//		$sub = $menu->addSubmenu('Title');
		
    }

}
