<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');
require  'classes/tag_info.php';
require 'classes/codee_mytemplate.php';
require 'classes/codee_datasource.php';
require_once APPPATH.'libraries/Template.php';



class Codee_mcp {
	var $tag_info;

	function __construct() {
		$this->tag_info = new Codee_tag_info();
	}
	
	public function index()
	{
    	//return "<h1>Hey</h1>";
		$vars = array();

		$view = ee('View')->make('codee:index');

		ee()->view->header = array(
			'title' => 'Codee / Edit Templates'
			);


		// ee()->load->model('codee_model');
	
        $theme_url = ee()->config->item('theme_folder_url') . 'third_party/';
        if (defined('URL_THIRD_THEMES')) {
            $theme_url = URL_THIRD_THEMES;
        }
		$vars['script_tag'] ='';
		
		
		if (ee()->config->item('site_url') == 'http://codee.localhost/') {
			$bundle_mtime = filemtime( PATH_THIRD . '/codee/javascript/dev-bundle/bundle.js');
			$vars['script_tag'] ='<script src="' . ee()->config->item('site_url') . 'system/user/addons/codee/javascript/dev-bundle/bundle.js?v=' . $bundle_mtime . '"></script>';
		} else {
			ee()->cp->load_package_js('dist/bundle');
		}
		
		
        
        ee()->cp->add_to_head('<link rel="stylesheet" href="'.$theme_url.'codee/blueprintjs/core/dist/blueprint.css" type="text/css" media="screen" />');


		 
		// return $view->render($vars);
		return array(
			'heading'    => 'Codee Template Manager',
            'breadcrumb' => array(), //array(ee('CP/URL')->make('addons/settings/codee')->compile() => 'Codee'),
            'body'       => $view->render($vars)
            );



	}

	public function editor() {
		//return "<h1>Editor</h1>";
		// return $this->_render('index', $vars);

	}

	public function ajax() {
		$resp['some_message'] = 'something';

		ee()->output->send_ajax_response($resp);
	}

	public function get_groups() {
		
		$template_groups = ee('Model')->get('TemplateGroup')
		->filter('site_id', ee()->config->item('site_id'))
		->order('group_order', 'asc');
		$groups = array();
		foreach ($template_groups->all() as $group)
		{
			$groups[] = array(
				'group_name'=>$group->group_name,
				'group_id'=>$group->group_id,
				'site_id'=>$group->site_id,
				'group_order'=>$group->group_order,
				'is_site_default'=>$group->is_site_default
				);
		}
		

		ee()->output->send_ajax_response($groups);	
	}

	public function get_all_templates() {
		
		$template_groups = ee('Model')->get('TemplateGroup')
		->filter('site_id', ee()->config->item('site_id'))
		->order('group_order', 'asc');
		foreach ($template_groups->all() as $group)
		{
			$templates = $group->Templates;
			$template_arr = array();
			foreach ($templates as $t)
			{

				$templates_arr[] = array(
					'template_id' => $t->template_id,
					'site_id' => $t->site_id,
					'group_id' => $t->group_id,
					'template_name' => $t->template_name,
					'template_type' => $t->template_type,
				//	'template_data' => $t->template_data,
					'template_notes' => $t->template_notes,
					'edit_date' => $t->edit_date,
					'last_author_id' => $t->last_author_id,
					'cache' => $t->cache,
					'refresh' => $t->refresh,
					'no_auth_bounce' => $t->no_auth_bounce,
					'enable_http_auth' => $t->enable_http_auth,
					'allow_php' => $t->allow_php,
					'php_parse_location' => $t->php_parse_location,
					'hits' => $t->hits,
					'protect_javascript' => $t->protect_javascript
					);
			}
		}

		ee()->output->send_ajax_response($templates_arr);	
	}

	public function get_template($template_id) {
		$t = ee('Model')->get('Template', $template_id)
		->with('TemplateGroup')
		->filter('site_id', ee()->config->item('site_id'))
		->first();

		// get array of member groups so that it can save the member groups with it. (see func renderAccessPartial in \system\ee\EllisLab\ExpressionEngine\Controller\Design\Template.php)
		$member_groups = ee('Model')->get('MemberGroup')
		->fields('group_id', 'group_title')
		->filter('site_id', ee()->config->item('site_id'))
		->filter('group_id', '!=', 1)
		->all();
		$allowed_member_groups = array_diff(
			$member_groups->pluck('group_id'),
			$t->getNoAccess()->pluck('group_id')
		);
		$allowed_member_groups_arr = array();
		foreach($allowed_member_groups as $id) {
			$allowed_member_groups_arr[] = $id;
		}

		

		$templates_arr = array(
				'template_id' => $t->template_id,
				'site_id' => $t->site_id,
				'group_id' => $t->group_id,
				'template_name' => $t->template_name,
				'template_type' => $t->template_type,
				'template_data' => $t->template_data,
				'template_notes' => $t->template_notes,
				'edit_date' => $t->edit_date,
				'last_author_id' => $t->last_author_id,
				'cache' => $t->cache,
				'refresh' => $t->refresh,
				'no_auth_bounce' => $t->no_auth_bounce,
				'enable_http_auth' => $t->enable_http_auth,
				'allow_php' => $t->allow_php,
				'php_parse_location' => $t->php_parse_location,
				'hits' => $t->hits,
				'protect_javascript' => $t->protect_javascript,
				'cp_edit_url' => ee('CP/URL')->make('/cp/design/template/edit/' . $t->template_id ),
				'allowed_member_groups' => $allowed_member_groups_arr
		);
		
		ee()->output->send_ajax_response($templates_arr);

	}

	public function get_autocomplete_tags() {
		$tag_obj = $this->tag_info->get_tags();
		$tags = $tag_obj['tags'];
		$tagsWithData = $this->getTagsWithLoadedDataSource($tags);
		ee()->output->send_ajax_response($tagsWithData);
		
		

	}

	public function getTagsWithLoadedDataSource($tags) {
		$data = new Codee_DataSource;
		foreach ($tags as $key => &$tag ) {
			if ($key[0] == "_") {
				// do nothing
			} else if (is_string($tag)) {
				// if it's not a tag that uses a key eg array('segment_1','segment_2') 
				// then convert it to key/value eg array('segment_1'=>array('name'=>'segment_1'), 'segment_2'=>array('name'=>'segment_2'), )
				$tags[$tag] = array('name' => $tag);
				unset($tags[$key]); // delete
			} else {
				$tag['name'] = $key; // useful to have a name 
			}

		}
		unset($tag);

		if (isset($tags['_dataSources'])) {
			foreach ($tags['_dataSources'] as $datasourceName) {
				$newTags = $data->get_data_source($datasourceName);	
				foreach ($newTags as $key => $newTag) {
					$tags[$key] = $newTag;
				}
			}
			
		}
		foreach ($tags as $tagName => &$tag) {
			// load extra tags, for example the field names in {exp:channel:entries}
			
			// load extra parameters, for example the channel names in {exp:channel:entries channel=""}
			if (isset($tag['parameters'])) {
				
				// change array('paramName1', 'paramName2') to array('paramName1'=>array(),'paramName2'=>array())
				foreach ($tag['parameters'] as $paramName => $param ) {
					if (is_string($param) ) {
						$tag['parameters'][$param] = array();
						unset($tag['parameters'][$paramName]);
					}
				}

				foreach ($tag['parameters'] as $paramName => &$param ) {	

					// if parameter is just a list of items (eg 'sort' => array('asc','desc') ) then move them to the values key
					if (!isset($param['values']) && !isset($param['_dataSources']) && is_array($param) ) {
						$param = array('values' => $param);
					}
					// go through each parameter value. If it's just a string replace with array('value'=>'whatever')..
					if (isset($param['values'])) {
						if (!is_array($param['values'])) $param['values'] = array($param['values']);
						foreach ($param['values'] as $key => $val) {
							if (is_string($val)) {
								$param['values'][$val] = array('name'=> $val);
								unset($param['values'][$key]);
							}
						}
					}
				

					if (isset($param['_dataSources'])) {
						foreach ($param['_dataSources'] as $datasourceName) {
							$newTags = $data->get_data_source($datasourceName);	
							if (!isset($param['values'])) $param['values'] = array();
							if (!is_array($param['values'])) $param['values'] = array($param['values']);
							foreach ($newTags as $newKey => $newTag) {
								$param['values'][$newKey] = $newTag;
							}
						}
						// $param['values'] = array_merge($newParameter['values'], $param['values']);
					}
				}
				unset($param);
			}
			// recursivly call this function on the variables of any tag pairs.
			if (isset($tag['variables'])) {
				$tag['variables'] = $this->getTagsWithLoadedDataSource($tag['variables']);
			}
		}
		unset($tag);
		return $tags;	
	}


	public function save_template($template_id) {
		$t = new Codee_MyTemplate;
		$t->save_template($template_id);
	}

	public function save_template_settings() {
		
		$template_id = intval(ee()->input->post('template_id'));
		$t = new Codee_MyTemplate;
		$t->save_template_settings($template_id);
	}

	public function new_template() {
		$t = new Codee_MyTemplate;
		$t->new_template(ee()->input->post('group_id'), ee()->input->post('template_name'), ee()->input->post('save_template_file'));
	}

	public function new_template_group() {
		$t = new Codee_MyTemplate;
		$t->new_template_group(ee()->input->post('group_name'), ee()->input->post('is_default'));
	}


	public function get_data_source() {
		$data_source_name = ee()->input->get('data_source_name');
		$data = new Codee_DataSource;
		$result =$data->get_data_source($data_source_name);
		ee()->output->send_ajax_response($result);
	}

	

}

// END CLASS



/* End of file mcp.module_name.php */
/* Location: ./system/user/addons/modules/module_name/mcp.module_name.php */