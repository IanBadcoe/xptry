<?php

$config = array(
      'author'      => 'Patrick Woodcock',
      'author_url'  => 'https://patrickw.tech',
      'name'        => 'Codee Template Manager',
      'description' => 'The IDE for EE',
      'version'     => '1.2.0',
      'namespace'   => 'Codee',
      'settings_exist' => true,
      'docs_url' => false

);

if (! defined('CODEE_VERSION')) {
    define('CODEE_VERSION', $config['version']);
    define('CODEE_NAME', $config['name']);
    define('CODEE_DESCRIPTION', $config['description']);
    define('CODEE_SETTINGS_EXIST', $config['settings_exist']);
    define('CODEE_DOCS', $config['docs_url']);
}


return $config;