<?php
if (! defined('BASEPATH')) {
	exit('No direct script access allowed');
}

require_once PATH_THIRD . 'codee/addon.setup.php';

class Codee_upd {

	public $version = CODEE_VERSION;
	public $name = 'Codee';

	public function install()
	{

		ee()->db->insert(
			'modules',
			array(
				'module_name'        => $this->name,
				'module_version'     => $this->version,
				'has_cp_backend'     => 'y',
				'has_publish_fields' => 'n'
				)
			);
		
		return true;
	}

	public function update($current = '')
	{
		if (version_compare($current, $this->version, '='))
		{
			return FALSE;
		}

		if (version_compare($current, $this->version, '<'))
		{
        // Do your update code here
		}

		return TRUE;
	}

	public function uninstall() {
        // remove references from modules
        ee()->db->where('module_name', $this->name);
        ee()->db->delete('modules');
        return true;
	}
}


