<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');
use EllisLab\ExpressionEngine\Controller\Design\AbstractDesign as AbstractDesignController;

class Codee_MyTemplate extends AbstractDesignController  {
	function __construct()
	{
		// parent::__construct();
	}

	/**
	 * Determines if the logged in user has edit privileges for a given template
	 * group. We need either a group's unique id or a template's unique id to
	 * determine access.
	 *
	 * @param  int  $group_id    The id of the template group in question (optional)
	 * @param  int  $template_id The id of the template in question (optional)
	 * @return bool TRUE if the user has edit privileges, FALSE if not
	 */
	protected function hasEditTemplatePrivileges($group_id = NULL, $template_id = NULL)
	{
		// If the user is a Super Admin, return true
		if (ee()->session->userdata['group_id'] == 1)
		{
			return TRUE;
		}

		if ( ! $group_id)
		{
			if ( ! $template_id)
			{
				return FALSE;
			}
			else
			{
				$group_id = ee('Model')->get('Template', $template_id)
					->fields('group_id')
					->first()
					->group_id;
			}
		}

		return array_key_exists($group_id, ee()->session->userdata['assigned_template_groups']);
	}




	public function save_template($template_id) {
		$errors = NULL;

		if ( ! ee()->cp->allowed_group('can_edit_templates'))
		{
			show_error(lang('unauthorized_access'));
		}

		$template = ee('Model')->get('Template', $template_id)
			->with('TemplateGroup')
			->filter('site_id', ee()->config->item('site_id'))
			->first();

		if ($version_id = ee()->input->get('version'))
		{
			$version = ee('Model')->get('RevisionTracker', $version_id)->first();

			if ($version)
			{
				$template->template_data = $version->item_data;
			}
		}

		if ( ! $template)
		{
			show_error(lang('error_no_template'));
		}

		$group = $template->getTemplateGroup();

		if ($this->hasEditTemplatePrivileges($group->group_id) === FALSE)
		{
			show_error(lang('unauthorized_access'));
		}

		$template_result = $this->validateTemplate($template);
		$route_result = $this->validateTemplateRoute($template);
		$result = $this->combineResults($template_result, $route_result);

// 		if ($template_result instanceOf ValidationResult)
// 		{
// 			$errors = $result;


// 			if ($template_result->isValid())
// 			{
				$template->save();
				// Save a new revision
				$this->saveNewTemplateRevision($template);

				ee()->output->send_ajax_response(array('status' => 'ok'));

// 			}
// 		} else {
// 			ee()->output->send_ajax_response(array('status' => 'fail'));
// 		}

	}

	public function save_template_settings($template_id)
	{
		$errors = NULL;

		if ( ! ee()->cp->allowed_group('can_edit_templates'))
		{
			show_error(lang('unauthorized_access'));
		}

		$template = ee('Model')->get('Template', $template_id)
			->filter('site_id', ee()->config->item('site_id'))
			->first();

		if ( ! $template)
		{
			show_error(lang('error_no_template'));
		}

		$group = $template->getTemplateGroup();

		if ($this->hasEditTemplatePrivileges($group->group_id) === FALSE)
		{
			ee()->output->send_ajax_response(array('status' => 'unauthorised_access'));
		}

		$result = $this->validateTemplate($template);
		// $route_result = $this->validateTemplateRoute($template);
		// this function doesn't work because validationResult is wrong $result = $this->combineResults($template_result, $route_result);

		// if ($result instanceOf ValidationResult)
		// {
			$errors = $result;


			if ($result->isValid())
			{
				$template->save();
				ee()->output->send_ajax_response(array('status' => 'ok'));
				
			} else {
				ee()->output->send_ajax_response(array('status' => 'error'));
			}
		// } else {
		// 	$msg = 'Validation error. ';
		// 	if (isset($template_result) & isset($template_result->failed)) {
		// 		foreach ($template_result->failed as $key => $x) {
		// 			$msg.= " Error on field " . $key . ". ";
		// 		}
		// 	}

		// 	ee()->output->send_ajax_response(array('status' => $msg));
		// }

	}



	function new_template($group_id,$template_name,$save_template_file) {
		// see system\ee\EllisLab\ExpressionEngine\Controller\Design\Template.php create() function
		if ( ! ee()->cp->allowed_group('can_create_new_templates'))
		{
			//show_error(lang('unauthorized_access'), 403);
			ee()->output->send_ajax_response(array('status' => 'not_authorised'));
		}
		if ($this->hasEditTemplatePrivileges($group_id) === FALSE)
		{
			ee()->output->send_ajax_response(array('status' => 'not_authorised'));
		}
		$group = ee('Model')->get('TemplateGroup')
			->filter('group_id', $group_id)
			->filter('site_id', ee()->config->item('site_id'))
			->first();
		
		$template = ee('Model')->make('Template');
		$template->site_id = ee()->config->item('site_id');
		$template->TemplateGroup = $group;
		$template->NoAccess = NULL;
		$template->set(array(
			"submit"=>"edit",
			"template_name"=>$template_name,
			"template_type"=>"webpage",
			"template_id"=>""
		));
		$template->edit_date = ee()->localize->now;
		$template->last_author_id = ee()->session->userdata('member_id');
		$template->save();
		// $member_groups = ee('Model')->get('MemberGroup')
		// 	->filter('site_id', ee()->config->item('site_id'))
		// 	->filter('group_id', '!=', 1)
		// 	->all();

		// $allowed_member_groups = ee()->input->post('allowed_member_groups') ?: array();

		// $template->NoAccess = $member_groups->filter(function($group) use ($allowed_member_groups)
		// {
		// 	return ! in_array($group->group_id, $allowed_member_groups);
		// });

		// $data = array(
		// 		'group_id'				=> $group_id,
		// 		'template_name'			=> $template_name,
		// 		'template_data'			=> '',
		// 		'edit_date'				=> ee()->localize->now,
		// 		'save_template_file'	=> $save_template_file ? 'y' : 'n',
		// 		'last_author_id'		=> ee()->session->userdata['member_id'],
		// 		'site_id'				=> ee()->config->item('site_id')
		// );
		
		// $template_model = ee('Model')->make('Template', $data)->save();
		$this->saveNewTemplateRevision($template);
		ee()->output->send_ajax_response(array('status' => 'ok',
			'template_id' => $template->getId(),
			'template_name' => $template->template_name,
			'group_id' => $group_id
			
		));
	}
	
	function new_template_group($groupName,$isDefault) {
		// \system\ee\EllisLab\ExpressionEngine\Controller\Design\Group.php
		if ( ! ee()->cp->allowed_group('can_create_template_groups'))
		{
			ee()->output->send_ajax_response(array('status' => 'error', 'msg' => 'unauthorised access'));
		}

		$group = ee('Model')->make('TemplateGroup');
		$group->site_id = ee()->config->item('site_id');
		$group->group_name = $groupName;
		$group->is_site_default = $isDefault;

		if ($this->session->userdata('group_id') != 1)
		{
			$group->MemberGroups = ee('Model')->get('MemberGroup', $this->session->userdata('group_id'))->first();
		}

		$group->save();

		$duplicate = FALSE;

		// if (is_numeric(ee()->input->post('duplicate_group')))
		// {
		// 	$master_group = ee('Model')->get('TemplateGroup', ee()->input->post('duplicate_group'))->first();
		// 	$master_group_templates = $master_group->getTemplates();
		// 	if (count($master_group_templates) > 0)
		// 	{
		// 		$duplicate = TRUE;
		// 	}
		// }

		if ( ! $duplicate)
		{
			$template = ee('Model')->make('Template');
			$template->group_id = $group->group_id;
			$template->template_name = 'index';
			$template->template_data = '';
			$template->last_author_id = 0;
			$template->edit_date = ee()->localize->now;
			$template->site_id = ee()->config->item('site_id');
			$template->save();
		}
		// else
		// {
		// 	foreach ($master_group_templates as $master_template)
		// 	{
		// 		$values = $master_template->getValues();
		// 		unset($values['template_id']);
		// 		$new_template = ee('Model')->make('Template', $values);
		// 		$new_template->template_id = NULL;
		// 		$new_template->group_id = $group->group_id;
		// 		$new_template->edit_date = ee()->localize->now;
		// 		$new_template->site_id = ee()->config->item('site_id');
		// 		$new_template->hits = 0; // Reset hits
		// 		$new_template->NoAccess = $master_template->NoAccess;
		// 		if (ee()->session->userdata['group_id'] != 1)
		// 		{
		// 			$new_template->allow_php = FALSE;
		// 		}
		// 		$new_template->save();
		// 	}
		// }

		ee('CP/Alert')->makeInline('shared-form')
			->asSuccess()
			->withTitle(lang('create_template_group_success'))
			->addToBody(sprintf(lang('create_template_group_success_desc'), $group->group_name))
			->defer();

		ee()->functions->redirect(ee('CP/URL')->make('design/manager/' . $group->group_name));	
	}
	

	/**
	 * Sets a template entity with the POSTed data and validates it, setting
	 * an alert if there are any errors.
	 *
	 * @param TemplateModel $template A Template entity
	 * @return mixed FALSE if nothing was posted, void if it was an AJAX call,
	 *  or a ValidationResult object.
	 */
	private function validateTemplate( $template)
	{
		if (empty($_POST))
		{
			return FALSE;
		}

		$template->set($_POST);
		$template->edit_date = ee()->localize->now;
		$template->last_author_id = ee()->session->userdata('member_id');

		$result = $template->validate();

		$field = ee()->input->post('ee_fv_field');

		// The ajaxValidation method looks for the 'ee_fv_field' in the POST
		// data. Then it checks to see if the result object has an error
		// for that field. Then it'll return. Since we may be validating
		// a field on a TemplateRoute model we should check for that
		// befaore outputting an ajax response.
		if ( ! isset($_POST['save_modal'])
			&& isset($field)
			&& $template->hasProperty($field)
			&& $response = $this->ajaxValidation($result))
		{
			ee()->output->send_ajax_response($response);
		}

		if ($result->failed())
		{
			ee('CP/Alert')->makeInline('shared-form')
				->asIssue()
				->withTitle(lang('update_template_error'))
				->addToBody(lang('update_template_error_desc'))
				->now();
		}
		else
		{
			$member_groups = ee('Model')->get('MemberGroup')
				->filter('site_id', ee()->config->item('site_id'))
				->filter('group_id', '!=', 1)
				->all();

			$allowed_member_groups = ee()->input->post('allowed_member_groups') ?: array();

			$template->NoAccess = $member_groups->filter(function($group) use ($allowed_member_groups)
			{
				return ! in_array($group->group_id, $allowed_member_groups);
			});
		}

		return $result;
	}

	/**
	 * Sets a template route entity with the POSTed data and validates it,
	 * setting an alert if there are any errors.
	 *
	 * @param TemplateModel $template A Template entity
	 * @return mixed FALSE if nothing was posted, void if it was an AJAX call,
	 *  or a ValidationResult object.
	 */
	private function validateTemplateRoute($template)
	{
		if (IS_CORE || ! ee()->input->post('route'))
		{
			$template->TemplateRoute = NULL;
			return FALSE;
		}

		if ( ! $template->TemplateRoute)
		{
			$template->TemplateRoute = ee('Model')->make('TemplateRoute');
		}

		$template->TemplateRoute->set($_POST);
		$result = $template->TemplateRoute->validate();

		if ( ! isset($_POST['save_modal']) && $response = $this->ajaxValidation($result))
		{
			ee()->output->send_ajax_response($response);
		}

		if ($result->failed())
		{
			ee('CP/Alert')->makeInline('shared-form')
				->asIssue()
				->withTitle(lang('update_template_error'))
				->addToBody(lang('update_template_error_desc'))
				->now();
		}

		return $result;
	}

	/**
	 * Combines the results of two different model validation calls
	 *
	 * @param bool|ValidationResult $one FALSE (if nothing was submitted) or a
	 *   ValidationResult object.
	 * @param bool|ValidationResult $two FALSE (if nothing was submitted) or a
	 *   ValidationResult object.
	 * @return bool|ValidationResult $one FALSE (if nothing was submitted) or a
	 *   ValidationResult object.
	 */
	private function combineResults($one, $two)
	{
		$result = FALSE;

		if ($one instanceOf ValidationResult)
		{
			$result = $one;

			if ($two instanceOf ValidationResult && $two->failed())
			{
				foreach ($two->getFailed() as $field => $rules)
				{
					foreach ($rules as $rule)
					{
						$result->addFailed($field, $rule);
					}
				}
			}
		}
		elseif ($two instanceOf ValidationResult)
		{
			$result = $two;
		}

		return $result;
	}

}
