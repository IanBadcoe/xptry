<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');


class Codee_DataSource  {
	function __construct()
	{
		// parent::__construct();
	}

	function get_data_source($data_source_name) {
		if ($data_source_name == "fieldNames") {
			return $this->get_field_names();
		} else if ($data_source_name == "channelNames") {
			return $this->get_channel_names();
		} else if ($data_source_name == "categoryIds") {
			return $this->get_category_ids();
		} else if ($data_source_name == "categoryGroupIds") {
			return $this->get_category_group_ids();
		} else if ($data_source_name == "channelStatuses") {
			return $this->get_channel_statuses();
		} else if ($data_source_name == "categoryFieldNames") {
			return $this->get_category_field_names();
		} else if ($data_source_name == "siteNames") {
			return $this->get_site_names();
		} else if ($data_source_name == "authors") {
			return $this->get_authors();
		} else if ($data_source_name == "memberFields") {
			return $this->get_member_fields();
		} else if ($data_source_name == "relationshipFields") {
			return $this->get_relationship_fields();
		} else if ($data_source_name == "gridFields") {
			return $this->get_grid_fields();
		} else {
			throw new Exception("Unknown data source " . $data_source_name);
		}

	}
	function get_field_names() {
		$q = ee()->db->select("field_id, field_name, field_label, field_type")
			->from('exp_channel_fields')
			->where_in('site_id',array(0,ee()->config->item('site_id')))
			->where(array('field_type !=' => 'relationship' ))
			->order_by('field_name');
		// $q = ee()->db->query("select field_id, field_name, field_label, field_type from " . ee()->db->db_pre )
		$tags = array();
		foreach ( $q->get()->result() as $field) {
			$tags[$field->field_name] = array(
				'name' => $field->field_name,
				'label' => $field->field_label
			);
		}
		return $tags;
	}
	
	function get_channel_names() {
		$q = ee()->db->select("channel_name, channel_title ")
			->from('channels')
			->where(array('site_id'=> ee()->config->item('site_id')))
			->order_by('channel_name');
		$tags = array();
		foreach ( $q->get()->result() as $channel) {
			$tags[$channel->channel_name] = array(
				'name' => $channel->channel_name,
				'label' => $channel->channel_title
			);
		}
		return $tags;
	}

	function get_channel_statuses() {
		$q = ee()->db->select("statuses.status")
			->from('statuses ')
			->order_by('status_order');
			
		$tags = array();
		foreach ( $q->get()->result() as $row) {
			$tags[$row->status] = array(
				'name' => $row->status,
				'label' => 'Status'
			);
		}
		return $tags;
	}
	
	
	function get_category_ids() {
		$q = ee()->db->select("cat_id, cat_name ")
			->from('categories')
			->where(array('site_id'=> ee()->config->item('site_id')))
			->order_by('cat_name')
			->limit(50);
		$tags = array();
		foreach ( $q->get()->result() as $cat) {
			$tags[$cat->cat_id] = array(
				'name' => $cat->cat_id,
				'label' => $cat->cat_name
			);
		}
		return $tags;
	}
	


	function get_category_group_ids() {
		$q = ee()->db->select("group_name, group_id ")
			->from('category_groups')
			->where(array('site_id'=> ee()->config->item('site_id')))
			->order_by('group_name')
			->limit(50);
		$tags = array();
		foreach ( $q->get()->result() as $group) {
			$tags[$group->group_id] = array(
				'name' => $group->group_id,
				'label' => $group->group_name
			);
		}
		return $tags;
	}
	
	function get_category_field_names() {
		$q = ee()->db->select("field_name, field_label")
			->from('category_fields')
			->where(array('site_id'=> ee()->config->item('site_id')))
			->order_by('field_order')
			->limit(50);
		$tags = array();
		foreach ( $q->get()->result() as $row) {
			$tags[$row->field_name] = array(
				'name' => $row->field_name,
				'label' => $row->field_label
			);
		}
		return $tags;
	}
	
	function get_site_names() {
		$q = ee()->db->select("site_name, site_label")
			->from('sites')
			->order_by('site_label')
			->limit(50);
		$tags = array();
		foreach ( $q->get()->result() as $row) {
			$tags[$row->site_name] = array(
				'name' => $row->site_name,
				'label' => $row->site_label
			);
		}
		return $tags;
	}
	
	
	function get_authors() {
		$q = ee()->db->select("member_id, username")
			->from('members')
			->order_by('member_id')
			->limit(20);
		$tags = array();
		foreach ( $q->get()->result() as $row) {
			$tags[$row->member_id] = array(
				'name' => $row->member_id,
				'label' => $row->username
			);
		}
		return $tags;
	}

	
	
	function get_member_fields() {
		$q = ee()->db->select("m_field_name, m_field_label")
			->from('member_fields')
			->order_by('m_field_name');
		$tags = array();
		foreach ( $q->get()->result() as $row) {
			$tags[$row->m_field_name] = array(
				'name' => $row->m_field_name,
				'label' => $row->m_field_label
			);
		}
		return $tags;
	}

	function get_relationship_parameters() {
		return array(
			'author_id' => array('values'=>$this->get_authors() ),
			'backspace' => array(array()),
			'category' => array('values'=>$this->get_category_ids() ),
			'channel' => array('values'=>$this->get_channel_names() ),
			'entry_id' => array(),
			'group_id' => array(),
			'offset' => array(),
			'orderby' => array('values'=>array("comment_total","date","edit_date","entry_id","expiration_date","most_recent_comment","random","screen_name","status","title","url_title","username","view_count_one","view_count_two","view_count_three","view_count_four")),
			'show_expired' => array('values'=>array('yes','no')),
			'show_future_entries' => array('values'=>array('yes','no')),
			'sort' => array('values'=>array('asc','desc')),
			'start_on' => array(),
			'status' => array('values'=>$this->get_channel_statuses()),
			'stop_before' => array(),
			'url_title' => array(),
			'username' => array()
		);
	}

	function get_relationship_fields() {
		$parameters = $this->get_relationship_parameters();
		$q = ee()->db->select("field_id, field_name, field_label, field_type, field_settings")
			->from('channel_fields')
			->where_in('site_id',array(0,ee()->config->item('site_id')))
			->where(array('field_type' => 'relationship' ))
			->order_by('field_name');
		$tags = array();
		foreach ( $q->get()->result() as $rel_field) {

			$field_settings = unserialize(base64_decode($rel_field->field_settings));

			$fields_query = ee()->db->select("field_id, field_name, field_label, field_type, field_settings")
			->from('channel_fields')
			->where_in('site_id',array(0,ee()->config->item('site_id')));
			if (isset($field_settings['channels']) && is_array($field_settings['channels']) && count($field_settings['channels'])>0 ) {
				$channel_id_csv = implode(',',$field_settings['channels']);
				//$fields_query->where("`group_id` in (select field_group from " . ee()->db->dbprefix('channels') . " where channel_id in ($channel_id_csv))" );
			}

			if ($field_settings['allow_multiple']) {
				$variables = array();
				foreach ( $fields_query->get()->result() as $field) {
					$f = $rel_field->field_name . ':' . $field->field_name;
					$variables[$f] = array(
						'name' => $f,
						'label' => $field->field_label
					);		
				}
				$tags[$rel_field->field_name] = array(
					'tagType' => 'pair',
					'name' => $rel_field->field_name,
					'label' => $rel_field->field_label,
					'tagDescription' =>  "Relationships are an extremely powerful tool that allow you to connect Entries in one Channel to those in another one, or even to other entries in the same channel. This ability allows you to store very complex content in your Channel entries." ,
					'tagHelpUrl' =>  'https://docs.expressionengine.com/latest/fieldtypes/relationships.html' ,
					'parameters' => $parameters,
					'variables' => $variables
				);

			} else {
				foreach ( $fields_query->get()->result() as $field) {
					$f = $rel_field->field_name . ':' . $field->field_name;
					$tags[$f] = array(
						'name' => $f,
						'label' => $field->field_label
					);		
				}
			}
			$tags[$rel_field->field_name . ':entry_ids'] = array(
				'name' => $rel_field->field_name . ':entry_ids',
				'label' => $rel_field->field_label
			);
			
			$tags[$rel_field->field_name . ':total_results'] = array(
				'name' => $rel_field->field_name . ':total_results',
				'label' => $rel_field->field_label
			);

		}
		return $tags;
	}
	
	function get_grid_fields() {
		
		$q = ee()->db->select("field_id, field_name, field_label, field_type, field_settings")
			->from('channel_fields')
			->where_in('site_id',array(0,ee()->config->item('site_id')))
			->where(array('field_type' => 'grid' ))
			->order_by('field_name');
		$grid_fields = $q->get()->result();
		if (count($grid_fields) == 0 ) return array();

		$grid_columns = ee()->db->select("f.field_id, c.col_label, c.col_name")
			->from('channel_fields f')
			->join('grid_columns c', 'c.field_id = f.field_id')
			->where_in('f.site_id',array(0,ee()->config->item('site_id')))
			->where(array('f.field_type' => 'grid' ))
			->get()->result();
		
		foreach($grid_fields as $field) {
			$variables = array(
				$field->field_name . ':' . 'count' => array(),
				$field->field_name . ':' . 'field_row_count' => array(),
				$field->field_name . ':' . 'field_row_index' => array(),
				$field->field_name . ':' . 'field_total_rows' => array(),
				$field->field_name . ':' . 'index' => array(),
				$field->field_name . ':' . 'row_id' => array(),
				$field->field_name . ':' . 'switch=' => array(),
				$field->field_name . ':' . 'total_rows' => array(),
			);
			$parameters = array(
				'backspace'=>array(),
				'dynamic_parameters'=>array('values'=>array('backspace','dynamic_parameters','fixed_order','limit','offset','orderby','row_id','sort')),
				'fixed_order'=>array(),
				'limit'=>array(),
				'offset'=>array(),
				'orderby'=>array('values'=>array('random')),
				'row_id'=>array(),
				'sort'=>array('values'=>array('asc','desc')),
			);
			foreach($grid_columns as $column) {
				if ($column->field_id == $field->field_id) {
					$variables[$field->field_name . ':' . $column->col_name] = array(
						'name' => $field->field_name . ':' . $column->col_name,
						'label' => $column->col_label
					);
					$parameters['search:' . $column->col_name] = array('values'=>array('not','|','&&','=','<','>','<=','>=','IS_EMPTY','\W'));
					$parameters['orderby']['values'][] = $column->col_name;
				}
			}
			$variables[$field->field_name . ':' . 'next_row'] =
			$variables[$field->field_name . ':' . 'prev_row'] = array(
				'tagType' => 'pair',
				'name' => $field->field_name . ':' . 'prev_row',
				'label' => 'Previous row',
				'variables' => $variables
			);
			$variables[$field->field_name . ':' . 'next_row']['name'] = $field->field_name . ':' . 'next_row';
			$variables[$field->field_name . ':' . 'next_row']['label'] = 'Next row';

			$tags[$field->field_name] = array(
				'tagType' => 'pair',
				'name' => $field->field_name,
				'label' => $field->field_label,
				'tagDescription' =>  "The Grid field in ExpressionEngine provides a way to group fieldtypes in repeatable rows. This is useful for when you need to group a subset of data in your channel entry form that may or may not have a varying number of rows." ,
				'tagHelpUrl' =>  'https://docs.expressionengine.com/latest/fieldtypes/grid.html' ,
				'parameters' => $parameters,
				'variables' => $variables
			);

			$tags[$field->field_name . ':average'] = array('name'=>$field->field_name . ':average', 'tagDescripion'=> 'Given a column name containing numeric data, returns the average of the column values in that field, or in the dataset paired down by additional criteria such as search.');
			$tags[$field->field_name . ':highest'] = array('name'=>$field->field_name . ':highest', 'tagDescripion'=> 'Given a column name containing numeric data, returns the hightest of the column values in that field, or in the dataset paired down by additional criteria such as search.');
			$tags[$field->field_name . ':lowest'] = array('name'=>$field->field_name . ':lowest', 'tagDescripion'=> 'Given a column name containing numeric data, returns the lowest of the column values in that field, or in the dataset paired down by additional criteria such as search.');
			$tags[$field->field_name . ':sum'] = array('name'=>$field->field_name . ':sum', 'tagDescripion'=> 'Given a column name containing numeric data, returns the sum of the column values in that field, or in the dataset paired down by additional criteria such as search.');
			$tags[$field->field_name . ':table'] = array('name'=>$field->field_name . ':table', 'tagDescripion'=> 'Outputs the data in the Grid field as a table. All parameters available to the primary tag are available in addition to these:');
			$tags[$field->field_name . ':total_rows'] = array('name'=>$field->field_name . ':total_rows', 'tagDescripion'=> 'When outside of a Grid field tag pair, this modifier can be used to get the total number of rows in a field given a specific criteria.');
			$tags[$field->field_name . ':next_row'] = array('name'=>$field->field_name . ':next_row', 'tagDescripion'=> 'Given a row ID, this tag pair will provide access to the next row in the field criteria. The row_id may be populated via a segment variable.');
			$tags[$field->field_name . ':prev_row'] = array('name'=>$field->field_name . ':prev_row', 'tagDescripion'=> 'Given a row ID, this tag pair will provide access to the previous row in the field criteria. The row_id may be populated via a segment variable.');
			

		}

		
		return $tags;
	}
	
}