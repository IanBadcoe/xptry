<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Codee_tag_info {
	function __construct() {

	}

	function get_tags() {
		$date_parameters = array(
			"%s" => array('label'=>"seconds	eg 00 to eg 59"),
			"%U" => array('label'=>"seconds since the epoch	 "),
			"%u" => array('label'=>"Microseconds (always 000000, see note, below)	eg 000000"),
			"%i" => array('label'=>"minutes	 00 - 59"),
			"%g" => array('label'=>"hour, 12-hour format without leading zeros	 1 to 12"),
			"%G" => array('label'=>"hour, 24-hour format without leading zeros	 0 to eg 23"),
			"%h" => array('label'=>"hour, 12-hour format	 01 to  12"),
			"%H" => array('label'=>"hour, 24-hour format	 00 to  23"),
			"%a" => array('label'=>"am /  pm"),
			"%A" => array('label'=>"AM /  PM"),
			"%d" => array('label'=>"day of the month, 2 digits with leading zeros	 01 to  31"),
			"%D" => array('label'=>"day of the week, textual, 3 letters	eg Fri"),
			"%j" => array('label'=>"day of the month without leading zeros	 1 to  31"),
			"%l" => array('label'=>"(lowercase ‘L’) - day of the week, textual, long	eg Friday"),
			"%w" => array('label'=>"day of the week, numeric	 0 (Sunday) to  6 (Saturday)"),
			"%N" => array('label'=>"ISO-8601 numeric representation of the day of the week, numeric	 1 (Monday) to 7 (Sunday)"),
			"%W" => array('label'=>"ISO-8601 week number of year, weeks starting on Monday	eg 42: the 42nd week in the year"),
			"%m" => array('label'=>"month	 01 to  12"),
			"%M" => array('label'=>"month, textual, 3 letters	eg Jan"),
			"%F" => array('label'=>"month, textual, long	eg January"),
			"%n" => array('label'=>"month without leading zeros	 1 to  12"),
			"%t" => array('label'=>"number of days in the given month	 28 to  31"),
			"%L" => array('label'=>"boolean for whether it is a leap year	 0 or  1"),
			"%o" => array('label'=>"ISO-8601 year number. This has the same value as Y, except that if the ISO week number (W) belongs to the previous or next year, that year is used instead.	 1999 or  2003"),
			"%y" => array('label'=>"year, 2 digits	eg 99"),
			"%Y" => array('label'=>"year, 4 digits	eg 1999"),
			"%z" => array('label'=>"day of the year	 0 to  365"),
			"%B" => array('label'=>"Swatch Internet time	 "),
			"%e" => array('label'=>"Timezone identifier	UTC, GMT, Atlantic/Azores"),
			"%I" => array('label'=>"(capital i)	1 if Daylight Saving Time,  0 otherwise"),
			"%O" => array('label'=>"Difference to Greenwich time (GMT) in hours	eg -0500"),
			"%P" => array('label'=>"Difference to Greenwich time (GMT) with colon between hours and minutes	eg -05:00"),
			"%c" => array('label'=>"ISO 8601 date	2004-02-12T15:19:21+00:00"),
			"%r" => array('label'=>"RFC 2822 formatting	eg Thu, 21 Dec 2000 16:01:07 +0200"),
			"%S" => array('label'=>"English ordinal suffix, 2 characters	eg th, eg nd"),
			"%T" => array('label'=>"Time zone setting of this machine	MDT"),
			"%Z" => array('label'=>"time zone offset in seconds. The offset for time zones west of UTC is always negative, and for those east of UTC is always positive.	eg -43200 to eg 43200"),
		);

		$tag_array = array(
			'format_version' => 1,
			'tags' => array(				
				'segment_1',
				'segment_2',
				'segment_3',
				'segment_4',
				'segment_5',
				'segment_6',
				'segment_7',
				'segment_8',
				'segment_9',
				'last_segment',
				'app_build',
				'app_version',
				'charset',
				'cp_session_id',
				'cp_url',
				'csrf_token',
				'current_path',
				'current_time' => array('parameters'=>array('format'=>array('values' => $date_parameters))),
				'current_query_string',
				'current_url',
				'debug_mode',
				'doc_url',
				'elapsed_time',
				'embed=',
				'encode=' => array('parameters'=>array('title')),
				'gzip_mode',
				'hits',
				'homepage',
				'is_ajax_request',
				'lang',
				'layout',
				'member_group',
				'member_profile_link',
				'password_max_length',
				'redirect=',
				'site_description',
				'site_name',
				'site_url',
				'template_name',
				'template_group',
				'template_id',
				'template_type',
				'template_edit_date',
				'theme_folder_url',
				'total_queries',
				'webmaster_email',
				'logged_in_email',
				'logged_in_group_description',
				'logged_in_group_id',
				'logged_in_group_title',
				'logged_in_ip_address',
				'logged_in_location',
				'logged_in_member_id',
				'logged_in_private_messages',
				'logged_in_screen_name',
				'logged_in_total_comments',
				'logged_in_total_entries',
				'logged_in_total_forum_posts',
				'logged_in_total_forum_replies',
				'logged_in_total_forum_topics',
				'logged_in_username',

				'if' => array(
					'tagType' =>  'pair' ,
					'label' => 'if',
					'variables' => array(
						'if:else',
						'if:elseif'
					)
				),
				'exp:channel:month_links' => array(
					'tagType' => 'pair',
					'label' => 'Archive Month Links',
					'tagDescription' =>  "The Archive Month Links tag displays a list of links for any months that contain Channel Entries. The links will point to your monthly archive page." ,
					'tagHelpUrl' =>  'https://docs.expressionengine.com/latest/channel/archive_month_links.html' ,
					'parameters' => array( 
						'channel' => array(
							'_dataSources' => array('channelNames'),
							'divider' => '|'
							),
						'limit' => true,
						'sort' => array('asc','desc'),
						'show_expired' => array('yes','no'),
						'show_future_entries' => array('yes','no'),
						'status' => array(
							'_dataSources' => array('channelStatuses'),
							'divider' => '|'
						)
					),
					'variables' => array(
						'month',
						'month_num',
						'month_short',
						"path=''",
						'year',
						'year_short',
						'year_heading' => array('tagType'=>'pair','variables'=> array('year'))
					)
				),
				'exp:channel:calendar' => array(
					'tagType' => 'pair',
					'label' => 'Calendar Tag',
					'tagDescription' =>  "This tag allows you to display a calendar which contains links based on entries in your channel. Here is an example of what you might use for a mini-calendar that you could place on each page of your site" ,
					'tagHelpUrl' =>  'https://docs.expressionengine.com/latest/channel/calendar.html' ,
					'parameters' => array( 
						"leading_zeroes" => array('yes','no' ),
						"month=" => array( ),
						"year" => array( ),
						"show_future_entries" => array('yes','no'  ),
						"start_day" => array("sunday", "monday", "tuesday", "wednesday", "thursday", "friday", "saturday" ),
						"switch" => array( 'calendarToday|calendarCell' ),
					),
					'variables' => array(
						"author",
						"comment_auto_path",
						"comment_entry_id_auto_path",
						"comment_url_title_auto_path",
						"comment_path",
						"comment_total",
						"date" => array('parameters'=>array('format'=>array('values' => $date_parameters))),
						"day_number",
						"day_path",
						"entry_id_path",
						"next_date" => array('parameters'=>array('format'=>array('values' => $date_parameters))),
						"next_path",
						"permalink",
						"previous_date" => array('parameters'=>array('format'=>array('values' => $date_parameters))),
						"previous_path",
						"profile_path",
						"switch",
						"title",
						"title_permalink",
						"url_title_path",
						"calendar_heading" => array('tagType'=>'pair', 'variables'=>array(
							'lang:weekday_abrev' => array('label' => "M, T, etc."),
							'lang:weekday_long' => array('label' => "Monday, Tuesday, etc."),
							'lang:weekday_short' => array('label' => "Mon, Tue, etc."),
						) ),
						"calendar_rows" => array('tagType'=>'pair',  ),
						"entries" => array('tagType'=>'pair',  ),
						"row_end" => array('tagType'=>'pair',  ),
						"row_start" => array('tagType'=>'pair',  ),
					)
				),
				'exp:channel:categories' => array(
					'tagType' =>  'pair' ,
					'label' =>  'Channel Categories Tag' ,
					'tagDescription' =>  "The Channel Categories tag enables you to show your Categories in a list." ,
					'tagHelpUrl' =>  'https://docs.expressionengine.com/latest/channel/categories.html' ,
					'parameters' => array( 
						'backspace' => array(),
						'category_group' => array( 'values' => array('not'), '_dataSources' => array('categoryGroupIds'), 'divider' => array('|') ),
						'channel' => array('_dataSources' => array('channelNames'), 'divider' => '|'),
						'class' => array(),
						'disable' => array('category_fields'),
						'id' => array(),
						'parent_only' => array('yes','no'),
						'restrict_channel' => array('yes','no'),
						'show' => array( 'values' => array('not'), '_dataSources' => array('categoryIds'), 'divider' => array('|') ),
						'show_empty' => array('yes','no'),
						'show_expired' => array('yes','no'),
						'show_future_entries' => array('yes','no'),
						'status' => array( '_dataSources' => array('channelStatuses'), 'divider' => '|'),
						'style' => array('nested','linear'),
					),
					'variables' => array(
						'_dataSources' => array('categoryFieldNames'),
						'category_description',
						'category_id',
						'parent_id',
						'category_image',
						'category_name',
						'category_url_title',
						'count',
						'path=',
						'total_results',
						'if active'
					)
					
				),
				'exp:channel:category_archive' => array(
					'tagType' =>  'pair' ,
					'label' =>  'Channel Category Archive Tag' ,
					'tagDescription' =>  "This tag is designed to let you list all of your channel entries and have them organized by category." ,
					'tagHelpUrl' =>  'https://docs.expressionengine.com/latest/channel/category_archive.html' ,
					'parameters' => array( 
						'backspace' => array(),
						'channel' => array('_dataSources' => array('channelNames'), 'divider' => '|'),
						'class' => array(),
						'disable' => array('category_fields'),
						'id' => array(),
						'orderby' => array('date','title','comment','most_recent_comment'),
						'show' => array( 'values' => array('not'), '_dataSources' => array('categoryIds'), 'divider' => array('|') ),
						'show_empty' => array('yes','no'),
						'show_future_entries' => array('yes','no'),
						'sort' => array('asc','desc'),
						'status' => array( '_dataSources' => array('channelStatuses'), 'divider' => '|'),
						'style' => array('nested','linear'),
					),
					'variables' => array(
						'categories' => array( 
							'label' => 'Categories',
							'tagType' => 'pair',
							'parameters' => array(),
							'variables' => array(
								'_dataSources' => array('categoryFieldNames'),
								'if active',
								'category_description',
								'category_id',
								'parent_id',
								'category_image',
								'category_name',
								'category_url_title',
								'path'
								)
							),
						'entry_titles' => array(
							'label' => 'Entry title for this category',
							'tagType' => 'pair',
							
							'variables' => array(
								'entry_date'  => array('parameters'=>array('format'=>array('values' => $date_parameters))),
								'entry_id',
								'entry_id_path',
								'path=',
								'title',
								'url_title'
							)	
						)
					)
				),
				'exp:channel:category_heading' => array(
					'tagType' =>  'pair' ,
					'label' =>  'Channel Category Heading Tag' ,
					'tagDescription' =>  "The purpose of this tag is to show the currently viewed Category as a heading." ,
					'tagHelpUrl' =>  'https://docs.expressionengine.com/latest/channel/category_heading.html' ,
					'parameters' => array( 
						'disable' => array('category_fields'),
						'relaxed_categories' => array("yes","no"),
						'channel' => array(
							'_dataSources' => array('channelNames'),
							'divider' => '|'
							)
					),
					'variables' => array(
						'_dataSources' => array('categoryFieldNames'),
						'category_description',
						'category_id',
						'parent_id',
						'category_image',
						'category_name',
						'category_url_title'
					)

				),
				
				'exp:channel:entries' => array(
					'tagType' =>  'pair' ,
					'label' =>  'Channel Entries tag' ,
					'tagDescription' =>  "The Channel Entries tag is the primary tag used to show the content you create and edit via your Control Panel\'s Create or Edit section. It\'s the most powerful tag in ExpressionEngine, and the most commonly used since its main function is to retrieve and display your site\'s content." ,
					'tagHelpUrl' =>  'https://docs.expressionengine.com/latest/channel/channel_entries.html' ,
					'parameters' => array( 
						'sort' => array('asc','desc'),
						'channel' => array(
							'_dataSources' => array('channelNames'),
							'divider' => '|'
							),
						'category' => array(
							'values' => array('not'),
							'_dataSources' => array('categoryIds'),
							'divider' => array('|','&')
							),
						'category_group' => array(
							'values' => array('not'),
							'_dataSources' => array('categoryGroupIds'),
							'divider' => array('|')
							),
						'disable' => array(
							'values' => array('categories','category_fields','custom_fields','member_data','pagination'),
							'divider' => '|',
							),
						'author_id' => array('_dataSources' => array('authors'), 'values'=>array('CURRENT_USER','NOT_CURRENT_USER','not')),
						'backspace' => true,
						'cache' => array('no','yes'),
						'refresh' => true,
						'display_by' => array('month','day','week'),
						'dynamic' => array('yes','no'),
						'entry_id' => array('not'),
						'entry_id_from' => true,
						'entry_id_to' => true,
						'fixed_order' => true,
						'group_id' => array('not'),
						'limit' => true,
						'month_limit' => array('100'),
						'offset' => true,
						'orderby' =>  array(
							'values' => array('comment_total','date','edit_date','entry_id','expiration_date','most_recent_comment','random','screen_name','status','title','url_title','username','view_count_one','view_count_two','view_count_three','view_count_four'),
							'_dataSources' => array('fieldNames'),
							'divider' => '|'
							),
						'paginate' => array('top','bottom','both','inline'),
						'paginate_base' => true,
						'paginate_type' => array('field'),
						'relaxed_categories' => array('no','yes'),
						'require_entry' => array('no','yes'),
						'search:FIELD_NAME' => array('=pickles|shoes', '=not pickles|shoes', 'pickles|shoes', 'not pickles|shoes', 'pickles&&shoes', 'not pickles&&shoes','<20','>=20', 'IS_EMPTY', 'not IS_EMPTY'),
						'site' => array('_dataSources'=>array('siteNames')),
						'show_current_week' => true,
						'show_expired' => true,
						'show_future_entries' => true,
						'show_pages' => true,
						'start_day' => true,
						'start_on' => true,
						'status' => array(
							'_dataSources' => array('channelStatuses'),
							'divider' => '|'
						),
						'stop_before' => true,
						'sticky' => true,
						'track_views' => true,
						'uncategorized_entries' => true,
						'url_title' => true,
						'username' => true,
						'week_sort' => true,
						'year'  => true,
						'month'  => true,
						'day' => true,
						'dynamic_parameters' => array('sort' ,'channel' ,'category' ,'category_group' ,'disable' ,'author_id' ,'backspace' ,'cache' ,'refresh' ,'display_by' ,'dynamic' ,'entry_id' ,'entry_id_from' ,'entry_id_to' ,'fixed_order' ,'group_id' ,'limit' ,'month_limit' ,'offset' ,'orderby' ,'paginate' ,'paginate_base' ,'paginate_type' ,'relaxed_categories' ,'require_entry' ,'search' ,'show_current_week' ,'show_expired' ,'show_future_entries' ,'show_pages' ,'start_day' ,'start_on' ,'status' ,'stop_before' ,'sticky' ,'track_views' ,'uncategorized_entries' ,'url_title' ,'username' ,'week_sort' ,'year' ,'month' ,'day'),
						'track_views' => array('one','two','three','four')
					),
					'variables' => array(
						'_dataSources' => array( 'fieldNames', 'relationshipFields', 'gridFields') ,
						'date_heading' => array( 
							'label' => 'Date heading',
							'tagType' => 'pair',
							'variables' => array(
								'entry_date' => array(
									'parameters' => array(
										'format' => array(
											'values' => array('%Y', '%d', '%m'),
											'divider' => ' '
											)
										)
									)
								)
							),
						'categories' => array( 
							'label' => 'Category IDs',
							'tagType' => 'pair',
							'parameters' => array(
								'backspace' => true,
								'limit' => true,
								'show' => array( '_dataSources' => array('categoryIds'), 'divider' => '|'),
								'show_group' => array( '_dataSources' => array('categoryGroupIds'), 'divider' => '|')
								),
							'variables' => array(
								'_dataSources' => array('categoryFieldNames'),
								'active',
								'category_description',
								'category_group',
								'category_id',
								'parent_id',
								'category_image',
								'category_name',
								'category_url_title',
								'path'
								)
							),
						'absolute_count',
						'absolute_results',
						'absolute_reverse_count',
						'aol_im',
						'author',
						'author_id',
						'avatar_image_height',
						'avatar_image_width',
						'avatar_url',
						'bio',
						'channel',
						'channel_id',
						'channel_short_name',
						'comment_auto_path',
						'comment_entry_id_auto_path',
						'comment_subscriber_total',
						'comment_total',
						'comment_url_title_auto_path',
						'current_page',
						'count',
						'cp_edit_entry_url',
						'edit_date' => array('parameters'=>array('format'=>array('values' => $date_parameters))),
						'email',
						'entry_date' => array('parameters'=>array('format'=>array('values' => $date_parameters))),
						'entry_id',
						'entry_id_path',
						'entry_site_id',
						'expiration_date' => array('parameters'=>array('format'=>array('values' => $date_parameters))),
						'forum_topic_id',
						'gmt_entry_date',
						'gmt_edit_date',
						'icq',
						'interests',
						'ip_address',
						'location',
						'member_search_path',
						'multi_field="'  => array('parameters'=>array('='=>array('_dataSources' => array( 'fieldNames')))), // @todo: make = act as parameter for tags that are their own parameter
						'msn_im',
						'occupation',
						'page_uri',
						'page_url',
						'paginate' => array('variables'=>array(
							'current_page','total_pages',
							'pagination_links'=>array('variables'=>array(
								'first_page'=>array('variables'=>array('pagination_url')),
								'previous_page'=>array('variables'=>array('pagination_url')),
								'page'=>array('variables'=>array('pagination_url','pagination_page_number','if current_page')),
								'next_page'=>array('variables'=>array('pagination_url')),
								'last_page'=>array('variables'=>array('pagination_url')),
							)),
							'if previous_page'=>array('variables'=> array('auto_path')),
							'if next_page'=>array('variables'=> array('auto_path'))
						)),
						'if next_page' => array('variables'=>array('auto_path')),
						'if previous_page' => array('variables'=>array('auto_path')),
						'permalink',
						'photo_url',
						'photo_image_height',
						'photo_image_width',
						'profile_path',
						'recent_comment_date'  => array('parameters'=>array('format'=>array('values' => $date_parameters))),
						'relative_url',
						'relative_date'  => array('parameters'=>array('format'=>array('values' => $date_parameters))),
						'reverse_count',
						'screen_name',
						'signature',
						'signature_image_height',
						'signature_image_url',
						'signature_image_width',
						'status',
						'switch',
						'title',
						'title_permalink',
						'total_results',
						'total_pages',
						'trimmed_url',
						'url',
						'url_or_email',
						'url_or_email_as_author',
						'url_or_email_as_link',
						'url_title',
						'url_title_path',
						'username',
						'week_date',
						'yahoo_im',
						'view_count_one',
						'view_count_two',
						'view_count_three',
						'view_count_four'
					)
				),
				'exp:channel:info' => array(
					'tagType' =>  'pair' ,
					'label' =>  'Channel Information Tag' ,
					'tagDescription' =>  "The purpose of this tag is to display general information about the specified Channel as set under Developer Tools, Channel Manager." ,
					'tagHelpUrl' =>  'https://docs.expressionengine.com/latest/channel/channel_info.html' ,
					'parameters' => array( 
						'channel' => array(
							'_dataSources' => array('channelNames'),
							'divider' => '|'
							),
					),
					'variables' => array(
						'channel_description',
						'channel_encoding',
						'channel_lang',
						'channel_title',
						'channel_url',
					)
				)	
			)
		);
		$tag_array['tags']['exp:channel:next_entry'] = array(
			'tagType' =>  'pair' ,
			'label' =>  'Next/Prev Entry tag' ,
			'tagDescription' =>  "The Next and Previous entry links allow you to generate links to the next or previous entry, based on the date of the entry." ,
			'tagHelpUrl' =>  'https://docs.expressionengine.com/latest/channel/entry_linking.html' ,
			'parameters' => array( 
				'channel' => array('_dataSources' => array('channelNames'),'divider' => '|'),
				'category' => array('values' => array('not'),'_dataSources' => array('categoryIds'),'divider' => array('|','&')),
				'category_group' => array('values' => array('not'),'_dataSources' => array('categoryGroupIds'),'divider' => array('|')),
				'entry_id' => array('not'),
				'show_expired' => true,
				'show_future_entries' => true,
				'status' => array(
					'_dataSources' => array('channelStatuses'),
					'divider' => '|'
				),
				'url_title' => true						
			),
			'variables' => array(
				'channel',
				'channel_short_name',
				'channel_url',
				'comment_entry_id_auto_path',
				'comment_url_title_auto_path',
				'entry_id',
				'id_path',
				'path',
				'title',
				'url_title',
				//"<a href=\"{path='template_group/template'}\">{title}</a>"
			)			
		);
		$tag_array['tags']['exp:channel:prev_entry'] = $tag_array['tags']['exp:channel:next_entry'];

		$tag_array['tags']['exp:channel:form'] = array(
			'tagType' =>  'pair' ,
			'label' =>  'Channel Form' ,
			'tagDescription' =>  "The Channel Form makes it possible to add and edit entries from outside of the Control Panel using a regular form inside a template." ,
			'tagHelpUrl' =>  'https://docs.expressionengine.com/latest/channel/channel_form/index.html' ,
			'parameters' => array( 
				'allow_comments' => array('yes','no'),
				'author_only' => array('yes','no'),
				'category' => array('values' => array('not'),'_dataSources' => array('categoryIds'),'divider' => array('|','&')),
				'channel' => array('_dataSources' => array('channelNames'),'divider' => '|'),
				'class' => array('yes','no'),
				'datepicker' => array('yes','no'),
				'dynamic_title' => array(),
				'entry_id' => array(),
				'error_handling' => array('inline'),
				'id' => array(),
				'include_assets' => array('yes','no'),
				'include_jquery' => array('yes','no'),
				'json' => array('yes','no'),
				'logged_out_member_id' => array(),
				'require_entry' => array('yes','no'),
				'return' => array(),
				'return_X' => array(),
				'rules:my_field_name' => array('required', 'matches', 'min_length[]', 'max_length[]', 'exact_length', 'alpha', 'alpha_numeric', 'alpha_dash', 'numeric', 'integer', 'is_natural', 'is_natural_no_zero', 'valid_email', 'valid_emails', 'valid_ip', 'valid_base64'),
				'rte_selector' => array(),
				'rte_toolset_id' => array(),
				'secure_action' => array('yes','no'),
				'secure_return' => array('yes','no'),
				'site' => array('_dataSources'=>array('siteNames')),
				'show_fields' => array('values' => 'not', '_dataSources' => array( 'fieldNames') ),
				'unique_url_title' => array('yes','no'),
				'url_title' => array(),
				'use_live_url' => array('yes','no')
			),
			'variables' => array(
				'my_field_name',
				'field:my_field_name',
				'error:my_field_name',
				'label:my_field_name',
				'instructions:my_field_name',
				'selected_option:my_field_name',
				'selected_option:my_field_name:label',
				'options:my_field_name',
				'custom_fields',
				'captcha',
				'channel_form_assets',
				'global_errors',
				'global_errors:count',
				'field_errors',
				'field_errors:count'
			)
		);

		$tag_array['tags']['exp:comment:entries'] = array(
			'tagType' =>  'pair' ,
			'label' =>  'Comment Entries Tag' ,
			'tagDescription' =>  "The Comment Entries Tag enables you to show the user-submitted comments associated with your entries." ,
			'tagHelpUrl' =>  'https://docs.expressionengine.com/latest/comment/index.html#id38' ,
			'parameters' => array( 
				'dynamic' => array('yes','no'),
				'entry_id' => array(),
				'comment_id' => array(),
				'limit' => array(),
				'orderby' => array('date','email','location','name','url','random'),
				'paginate' => array('top','bottom','base','inline'),
				'paginate_base' => array(),
				'show_expired' => array('yes','no'),
				'sort' => array('asc','desc'),
				'url_title' => array(),
				'channel' => array('_dataSources' => array('channelNames'),'divider' => '|'),
				'entry_status' => array(
					'_dataSources' => array('channelStatuses'),
					'divider' => '|'
				),
				'status' => array(),
				'author_id' => array('_dataSources' => array('authors')),
			),
			'variables' => array(
				'_dataSources' => array('memberFields'),
				'absolute_count',
				'author',
				'author_id',
				'aol_im',
				'avatar_image_height',
				'avatar_image_width',
				'avatar_url',
				'can_moderate_comment',
				'channel_short_name',
				'channel_title',
				'comment',
				'comment_stripped',
				'comment_auto_path',
				'comment_date',
				'comment_entry_id_auto_path',
				'comment_id',
				'comment_site_id',
				'comment_url_title_auto_path',
				'count',
				'editable',
				'edit_date',
				'email',
				'entry_author_id',
				'entry_id',
				'entry_id_path',
				'gmt_comment_date',
				'icq',
				'interests',
				'ip_address',
				'location',
				'group_id',
				'member_search_path',
				'msn_im',
				'occupation',
				'name',
				'permalink',
				'photo_url',
				'photo_image_height',
				'photo_image_width',
				'signature',
				'signature_image_height',
				'signature_image_url',
				'signature_image_width',
				'switch=',
				'title',
				'total_results',
				'total_comments',
				'url',
				'url_as_author',
				'url_or_email',
				'url_or_email_as_author',
				'url_or_email_as_link',
				'url_title_path',
				'username',
				'channel_id',
				'yahoo_im',
				'if no_results',
				'if is_ignored',
				'if comments_disabled',
				'if comments_expired',
				'if avatar',
				'if signature_image',
			)
			
		);

		$tag_array['tags']['exp:comment:notification_links'] = array(
			'tagType' =>  'pair' ,
			'label' =>  'Comment Notification Links Tag' ,
			'tagDescription' =>  "The {exp:comment:notification_links} tag can be to allow members to subscribe to an entry without commenting via a simple link. This tag may only be used on a single entry page." ,
			'tagHelpUrl' =>  'https://docs.expressionengine.com/latest/comment/index.html#comment-notification-links-tag' ,			
			'parameters' => array(
				'entry_id',
				'url_title'
			),
			'variables' => array(
					'if subscribed',
					'subscribe_link'
				)
		);


		return $tag_array;

	}
}